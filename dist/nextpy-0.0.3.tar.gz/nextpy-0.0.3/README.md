# NextPy

A Python CLI that wraps the NextJs CLI to add another unnecessary level of automation :P

<p align="center">
  <img src="img/NextPymax.png" alt="Image description" style="width: 500px; height: auto;">
</p>

---
